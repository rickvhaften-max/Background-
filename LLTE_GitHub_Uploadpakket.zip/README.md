# LLTE Roblox Background Check — iPhone installatie

## Bestanden uploaden naar GitHub

1. Bewaar het zipbestand in de app **Bestanden** op de iPhone.
2. Tik op de zip om deze uit te pakken.
3. Ga naar https://github.com/new, meld je aan en maak een **Private** repository met de naam `llte-background-check`.
4. Kies eventueel **Add a README file** bij het aanmaken zodat de repository direct een hoofdbranch heeft.
5. Open de repository in Safari. Kies **Add file** → **Upload files** (eventueel Safari → Vraag om desktopwebsite).
6. Kies deze drie bestanden uit de uitgepakte map: `worker.js`, `wrangler.jsonc`, `package.json`. Upload ze naar de **hoofdmap** van de repository, dus niet als zipbestand. Sla de wijzigingen op met **Commit changes** of **Propose changes** (als je een pull request maakt, merge deze naar `main`).

## Aan jouw bestaande Cloudflare Worker koppelen

1. Open https://dash.cloudflare.com → Workers & Pages → `llte-background-check`.
2. Ga naar **Settings** → **Builds** / **Build** → **Connect**.
3. Kies **GitHub**, autoriseer Cloudflare en selecteer je nieuwe repository.
4. Productiebranch: `main`. Root directory: leeg of `/` (repository root). Build command: leeg. Deploy command: `npx wrangler deploy`.
5. Sla de instellingen op. Bij nieuwe commits voert Cloudflare de deployment automatisch uit. Als het koppelen nog geen deployment triggert: maak in GitHub een kleine update aan de README, commit op main, en bekijk de buildstatus.

De Worker naam `llte-background-check` in `wrangler.jsonc` moet gelijk zijn aan de naam in Cloudflare.

## De Discord slashcommand-koppeling

Maak hiervoor een **nieuwe Discord applicatie** op https://discord.com/developers/applications (gebruik niet de Kovu-applicatie als die actief door Kovu wordt beheerd).

Stel in je Cloudflare Worker bij **Settings → Variables and Secrets** in:

- `DISCORD_APPLICATION_ID` = Application ID (geen geheim)
- `DISCORD_PUBLIC_KEY` = Public Key (geen bot-token)
- `DISCORD_GUILD_ID` = ID van je Discord server
- `DISCORD_BOT_TOKEN` = nieuw bot-token — **Secret** (geheim houden)
- `SETUP_KEY` = zelfgekozen lang willekeurig geheim — **Secret**
- `STAFF_ROLE_IDS` = komma-gescheiden ID's van de rollen die de check mogen uitvoeren (optioneel; gebruikers met Administrator / Manage Server kunnen het sowieso)

Bij Discord Developer Portal onder **General Information → Interactions Endpoint URL** gebruik je:

`https://llte-background-check.rickvhaften.workers.dev/interactions`

De Worker weigert Discord-aanroepen voordat de juiste `DISCORD_PUBLIC_KEY` is ingesteld.

Voeg de app aan de server toe met `applications.commands` en `bot` scopes (waar nodig) en minimale permissies.

Voor eenmalige slashcommand-registratie: open in Safari

`https://llte-background-check.rickvhaften.workers.dev/register?key=JE_SETUP_KEY`

Gebruik hiervoor je zelfgekozen setup key; dit is een gevoelig geheim en hoort niet in chat of screenshots. Verwijder na succesvolle registratie `SETUP_KEY` en `DISCORD_BOT_TOKEN` uit de Worker secrets als je de command niet opnieuw hoeft te registreren. De browsergeschiedenis kan de setup key bewaren: wis deze URL uit Safari-geschiedenis.

Test `/bgcheck username:RobloxNaam` in Discord. De check levert **alleen openbare Roblox-gegevens**, geen privégegevens, eigen banhistorie of afgeronde betrouwbaarheidsscore. Rapporten zijn ephemeral (alleen zichtbaar voor de gebruiker die het commando uitvoert). Alleen staff met de aangewezen rollen (of Administrator/Manage Server) kan de check uitvoeren.

## Onderhoud

Eenmaal gekoppeld hoeft de iPhone niet aan te blijven en Cloudflare vraagt geen handmatige herstart elke twee dagen. Dit geldt zolang je Worker actief is en je binnen de eventuele Cloudflare free-plan limieten blijft.
